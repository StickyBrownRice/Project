//#1 assign values to all 88 notes(including octaves) and rests
//#2 method#1: keyChecker(*input from the picture)
//#3 method#2: MusicTransposer(Array[][] song, int keyChecker, int key)
